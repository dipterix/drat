library(testthat)
library(rave)

test_check("rave")
