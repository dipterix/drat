library(testthat)
library(raveio)

test_check("raveio")
