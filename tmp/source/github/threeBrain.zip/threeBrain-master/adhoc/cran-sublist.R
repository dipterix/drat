spell_check()
R CMD check
check_rhub()
check_win_devel()
NEWS.md
DESCRIPTION
cran-comments.md
