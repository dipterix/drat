# Current submission (0.1.7):

CRAN check failed on `Debian` because package `qs` does not exist. `qs` is a CRAN package. Therefore I think this error was a false positive.

In this version, I removed `qs`, `RcppRedis` from dependence. 

Self check results in no error/warning/notes

Reverse dependency checks passed too.
