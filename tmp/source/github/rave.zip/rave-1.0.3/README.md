<img src="https://ars.els-cdn.com/content/image/1-s2.0-S1053811920X00152-cov200h.gif" height="116px" align="left" /><img src="https://raw.githubusercontent.com/beauchamplab/rave/master/inst/assets/images/logo-md.jpg" height="116px" align="right" />

# RAVE: __R__ __A__*nalysis and* __V__*isualization of intracranial* __E__*lectroencephalography*


For all RAVE info, including installation instructions, visit https://openwetware.org/wiki/RAVE 

<!-- badges: start -->
[![R-CMD-check](https://github.com/beauchamplab/rave/workflows/R-CMD-check/badge.svg)](https://github.com/beauchamplab/rave/actions)
<!-- badges: end -->

