# @export
# get_client_size = function(){
#   
#   e = getExecEnvirFromContext()
#   
#   if(shiny::is.reactivevalues(e$global_reactives)){
#     size = shiny::isolate(e$global_reactives$client_size)
#   }else{
#     size = NULL
#   }
#   return(size)
# }
# 
# 
# 
