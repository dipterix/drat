# Dev Checks

**Starting From 03/11/2019**

**Created by: Zhengjia Wang**

## Package Build Checks

| Package Check Results  | Stable | Dev (RAVE-Fir) |
|:------------------|:------:|:----:|
| MacOS, Ubuntu     | [![Build Status](https://travis-ci.org/beauchamplab/rave.svg?branch=master)](https://travis-ci.org/beauchamplab/rave) | [![Build Status](https://travis-ci.org/beauchamplab/rave.svg?branch=dev-0.1.9)](https://travis-ci.org/beauchamplab/rave) |
| Windows           | [![AppVeyor build status](https://ci.appveyor.com/api/projects/status/github/beauchamplab/rave?branch=master&svg=true)](https://ci.appveyor.com/project/beauchamplab/rave) | [![AppVeyor build status](https://ci.appveyor.com/api/projects/status/github/beauchamplab/rave?branch=dev-0.1.9&svg=true)](https://ci.appveyor.com/project/beauchamplab/rave) |

